﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace WpfApplication1 {
  public class ActiveProjectCheckConverter : IMultiValueConverter {
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
      string first = values[0] as string;
      string second = values[1] as string;
      if (string.IsNullOrEmpty(first) || string.IsNullOrEmpty(second))
        return false;
      return first == second;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
      throw new NotImplementedException();
    }
  }
}
