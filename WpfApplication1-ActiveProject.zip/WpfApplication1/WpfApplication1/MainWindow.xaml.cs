﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using GalaSoft.MvvmLight;

namespace WpfApplication1 {
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window {
    public MainWindow() {
      InitializeComponent();
      DataContext = new ViewModel();
    }
  }

  public class ViewModel : ViewModelBase {
    private ObservableCollection<Project> _projects;

    public ViewModel() {
      Projects = new ObservableCollection<Project>(
        new List<Project> {
          new Project {Id = "0", Name = "Project1"},
          new Project {Id = "1", Name = "Project2"},
          new Project {Id = "2", Name = "Project3"}
        });
      ActiveProject = Projects[0];
      //Test to switch ActiveProject after 3 seconds and verify if it's reflected in the View
      var tempTask = new Task
        (
        () => {
          Thread.Sleep(3000);
          Application.Current.Dispatcher.BeginInvoke(new Action(() => ActiveProject = Projects[1]));
        },
        TaskCreationOptions.LongRunning
        );
      tempTask.Start();
    }

    public ObservableCollection<Project> Projects {
      get {
        return _projects;
      }
      set {
        _projects = value;
        RaisePropertyChanged(() => Projects);
      }
    }

    private Project _activeProject;

    public Project ActiveProject {
      get {
        return _activeProject;
      }
      set {
        if (value == _activeProject)
          return;
        _activeProject = value;
        RaisePropertyChanged(() => ActiveProject);
      }
    }
  }

  public class Project : ObservableObject {
    private string _id;
    private string _name;

    public string Name {
      get {
        return _name;
      }
      set {
        _name = value;
        RaisePropertyChanged(() => Name);
      }
    }

    public string Id {
      get {
        return _id;
      }
      set {
        _id = value;
        RaisePropertyChanged(() => Id);
      }
    }
  }
}
